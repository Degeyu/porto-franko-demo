import { readdir, readFile, writeFile, mkdir, copyFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

// A flat static export can be uploaded through GitHub's file uploader.
// Relative links work under /porto-franko-demo/ as well as a custom domain.
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const output = path.resolve(process.argv[2] || path.join(root, '..', 'porto-franko-github-pages'));
await mkdir(output, { recursive: true });
const assets = new Map();
async function walk(directory, prefix = '') {
  for (const entry of await readdir(directory, { withFileTypes: true })) {
    const relative = prefix + entry.name;
    if (entry.isDirectory()) await walk(path.join(directory, entry.name), relative + '/');
    else {
      const name = entry.name;
      if ([...assets.values()].includes(name)) throw new Error(`Duplicate asset name: ${name}`);
      assets.set(relative, name);
    }
  }
}
await walk(path.join(root, 'dist'));
for (const [relative, name] of assets) {
  const source = path.join(root, 'dist', relative);
  if (/\.(html|css|js|svg)$/.test(name)) {
    let content = await readFile(source, 'utf8');
    for (const [asset, flat] of assets) content = content.replaceAll('/' + asset, './' + flat);
    content = content.replaceAll('href="/"', 'href="./"');
    await writeFile(path.join(output, name), content);
  } else await copyFile(source, path.join(output, name));
}
await writeFile(path.join(output, '.nojekyll'), '');
console.log(`Exported ${assets.size} files to ${output}`);
